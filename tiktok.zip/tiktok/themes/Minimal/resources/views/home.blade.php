<x-theme::layout>
    <x-theme::splash/>
    <x-theme::section.feature/>
    <x-theme::section.how-to/>
    <x-theme::section.about/>
    <x-theme::section.usage/>
    <x-theme::section.faq/>
</x-theme::layout>
