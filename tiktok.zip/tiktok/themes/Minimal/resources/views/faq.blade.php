<x-theme::layout>
    <x-slot:title>
        @lang('Frequently Asked Questions')
    </x-slot:title>
    <x-theme::splash/>
    <x-theme::section.faq>
        <x-slot:header>
            <h2>@lang('Frequently Asked Questions')</h2>
        </x-slot:header>
    </x-theme::section.faq>
</x-theme::layout>
