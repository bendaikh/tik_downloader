<div class="card license-card">
    <h4>License Status</h4>
    <div class="license-card-content">
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['license-status', $licenseStatus]) ?>">
            <?php echo e(str($licenseStatus)->title()); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\Users\Espacegamers\Documents\codecanyon apps\web apps\tiktokdown\tiktok\resources\views/components/admin/card/license-status.blade.php ENDPATH**/ ?>