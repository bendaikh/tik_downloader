<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.layout','data' => ['title' => 'Payment Settings']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Payment Settings']); ?>
    <div class="content-card card">
        <div class="heading">
            <h2>Payment Settings</h2>
            <p>Configure PayPal integration for donations</p>
        </div>

        <form
            action="<?php echo e(route('admin.payment-settings.update')); ?>"
            method="POST"
            id="paymentSettingsForm"
        >
            <?php echo csrf_field(); ?>
            
            <!-- PayPal Configuration Section -->
            <div class="settings-section">
                <h3>PayPal Configuration</h3>
                
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('paypal_client_id')]) ?>">
                    <label for="paypal_client_id">PayPal Client ID</label>
                    <input 
                        type="text" 
                        id="paypal_client_id" 
                        name="paypal_client_id" 
                        value="<?php echo e(config('payments.paypal_client_id')); ?>"
                        placeholder="Enter your PayPal Client ID"
                    >
                    <small>Get this from your PayPal Developer Dashboard</small>
                    <?php $__errorArgs = ['paypal_client_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('paypal_client_secret')]) ?>">
                    <label for="paypal_client_secret">PayPal Client Secret</label>
                    <input 
                        type="password" 
                        id="paypal_client_secret" 
                        name="paypal_client_secret" 
                        value="<?php echo e(config('payments.paypal_client_secret')); ?>"
                        placeholder="Enter your PayPal Client Secret"
                    >
                    <small>Get this from your PayPal Developer Dashboard</small>
                    <?php $__errorArgs = ['paypal_client_secret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-required', 'is-error'=> $errors->has('paypal_mode')]) ?>">
                    <label for="paypal_mode">PayPal Mode</label>
                    <select id="paypal_mode" name="paypal_mode" required>
                        <option value="sandbox" <?php echo e(config('payments.paypal_mode') == 'sandbox' ? 'selected' : ''); ?>>
                            Sandbox (Testing)
                        </option>
                        <option value="live" <?php echo e(config('payments.paypal_mode') == 'live' ? 'selected' : ''); ?>>
                            Live (Production)
                        </option>
                    </select>
                    <small>Use Sandbox for testing, Live for real payments</small>
                    <?php $__errorArgs = ['paypal_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-required', 'is-error'=> $errors->has('paypal_currency')]) ?>">
                    <label for="paypal_currency">Currency</label>
                    <select id="paypal_currency" name="paypal_currency" required>
                        <option value="USD" <?php echo e(config('payments.paypal_currency') == 'USD' ? 'selected' : ''); ?>>USD - US Dollar</option>
                        <option value="EUR" <?php echo e(config('payments.paypal_currency') == 'EUR' ? 'selected' : ''); ?>>EUR - Euro</option>
                        <option value="GBP" <?php echo e(config('payments.paypal_currency') == 'GBP' ? 'selected' : ''); ?>>GBP - British Pound</option>
                        <option value="CAD" <?php echo e(config('payments.paypal_currency') == 'CAD' ? 'selected' : ''); ?>>CAD - Canadian Dollar</option>
                        <option value="AUD" <?php echo e(config('payments.paypal_currency') == 'AUD' ? 'selected' : ''); ?>>AUD - Australian Dollar</option>
                    </select>
                    <?php $__errorArgs = ['paypal_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Donation Settings Section -->
            <div class="settings-section">
                <h3>Donation Settings</h3>
                
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('donation_enabled')]) ?>">
                    <label class="checkbox-label">
                        <input 
                            type="checkbox" 
                            name="donation_enabled" 
                            value="1" 
                            <?php echo e(config('payments.donation_enabled') ? 'checked' : ''); ?>

                        >
                        <span>Enable Donations</span>
                    </label>
                    <small>Show the donate button on the website</small>
                    <?php $__errorArgs = ['donation_enabled'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('donation_amounts')]) ?>">
                    <label for="donation_amounts">Donation Amounts (comma-separated)</label>
                    <input 
                        type="text" 
                        id="donation_amounts" 
                        name="donation_amounts" 
                        value="<?php echo e(config('payments.donation_amounts', '5,10,25,50,100')); ?>"
                        placeholder="5,10,25,50,100"
                    >
                    <small>Enter amounts separated by commas (e.g., 5,10,25,50,100)</small>
                    <?php $__errorArgs = ['donation_amounts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Instructions Section -->
            <div class="settings-section">
                <h3>Setup Instructions</h3>
                <div class="instructions">
                    <ol>
                        <li>Go to <a href="https://developer.paypal.com" target="_blank">PayPal Developer Dashboard</a></li>
                        <li>Create a new app or use an existing one</li>
                        <li>Copy the Client ID and Client Secret</li>
                        <li>Paste them in the fields above</li>
                        <li>Choose Sandbox for testing or Live for real payments</li>
                        <li>Save the settings</li>
                    </ol>
                </div>
            </div>

            <?php $__env->startPush('header'); ?>
                <button class="button is-primary" type="submit" form="paymentSettingsForm">Save Settings</button>
            <?php $__env->stopPush(); ?>
        </form>
    </div>

    <style>
        .settings-section {
            margin-bottom: 2rem;
            padding: 1.5rem;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }

        .settings-section h3 {
            margin-bottom: 1rem;
            color: #333;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .instructions {
            background: #e3f2fd;
            padding: 1rem;
            border-radius: 6px;
            border-left: 4px solid #2196f3;
        }

        .instructions ol {
            margin: 0;
            padding-left: 1.5rem;
        }

        .instructions li {
            margin-bottom: 0.5rem;
            color: #1976d2;
        }

        .instructions a {
            color: #2196f3;
            text-decoration: underline;
        }

        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
        }

        .checkbox-label input[type="checkbox"] {
            margin: 0;
        }
    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Espacegamers\Documents\codecanyon apps\web apps\tiktokdown\tiktok\resources\views/admin/payment-settings.blade.php ENDPATH**/ ?>