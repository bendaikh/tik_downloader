<?php
    $posts = \App\Models\Blog::published()->latest('published_at')->take(3)->get();
    $totalPosts = \App\Models\Blog::published()->count();
?>

<?php if($posts->count()): ?>
<section class="blog">
    <div class="container">
        <h2 class="section-title">Latest Blog Posts</h2>

        <div class="blog-grid">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/blog/<?php echo e($post->slug); ?>" class="blog-card">
                    <?php if($post->featured_image): ?>
                        <div class="blog-image" style="background-image:url('<?php echo e($post->featured_image); ?>')"></div>
                    <?php endif; ?>
                    <div class="blog-content">
                        <h3 class="blog-title"><?php echo e($post->title); ?></h3>
                        <p class="blog-excerpt"><?php echo e(\Illuminate\Support\Str::limit(strip_tags($post->description ?? $post->excerpt), 120)); ?></p>
                        <span class="read-more">Read More →</span>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <?php if($totalPosts > 3): ?>
        <div class="blog-actions">
            <a href="/blog" class="see-more-btn">
                <span>See All Blog Posts</span>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </a>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>
<?php /**PATH C:\Users\Espacegamers\Documents\codecanyon apps\web apps\tiktokdown\tiktok\themes/TTDown\resources\views/components/section/blog.blade.php ENDPATH**/ ?>