<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.layout','data' => ['title' => 'Google Analytics Settings']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Google Analytics Settings']); ?>
    <div class="content-card card">
        <div class="heading">
            <h2>Google Analytics Settings</h2>
            <p>Configure Google Analytics 4 (GA4) integration for your website</p>
        </div>

        <form
            action="<?php echo e(route('admin.google-analytics.update')); ?>"
            method="POST"
            id="googleAnalyticsForm"
        >
            <?php echo csrf_field(); ?>
            
            <!-- Google Analytics Configuration Section -->
            <div class="settings-section">
                <h3>Google Analytics Configuration</h3>
                
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('ga_measurement_id')]) ?>">
                    <label for="ga_measurement_id">Measurement ID (G-XXXXXXXXXX)</label>
                    <input 
                        type="text" 
                        id="ga_measurement_id" 
                        name="ga_measurement_id" 
                        value="<?php echo e(config('analytics.ga_measurement_id')); ?>"
                        placeholder="G-XXXXXXXXXX"
                        pattern="G-[A-Z0-9]{10}"
                    >
                    <small>Enter your Google Analytics 4 Measurement ID (starts with G-)</small>
                    <?php $__errorArgs = ['ga_measurement_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('ga_enabled')]) ?>">
                    <label class="checkbox-label">
                        <input 
                            type="checkbox" 
                            name="ga_enabled" 
                            value="1" 
                            <?php echo e(config('analytics.ga_enabled') ? 'checked' : ''); ?>

                        >
                        <span>Enable Google Analytics</span>
                    </label>
                    <small>Enable Google Analytics tracking on your website</small>
                    <?php $__errorArgs = ['ga_enabled'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Tracking Options Section -->
            <div class="settings-section">
                <h3>Tracking Options</h3>
                
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('ga_track_pageviews')]) ?>">
                    <label class="checkbox-label">
                        <input 
                            type="checkbox" 
                            name="ga_track_pageviews" 
                            value="1" 
                            <?php echo e(config('analytics.ga_track_pageviews', true) ? 'checked' : ''); ?>

                        >
                        <span>Track Page Views</span>
                    </label>
                    <small>Automatically track page views across your website</small>
                    <?php $__errorArgs = ['ga_track_pageviews'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('ga_track_events')]) ?>">
                    <label class="checkbox-label">
                        <input 
                            type="checkbox" 
                            name="ga_track_events" 
                            value="1" 
                            <?php echo e(config('analytics.ga_track_events', true) ? 'checked' : ''); ?>

                        >
                        <span>Track Custom Events</span>
                    </label>
                    <small>Track button clicks, form submissions, and other interactions</small>
                    <?php $__errorArgs = ['ga_track_events'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('ga_track_downloads')]) ?>">
                    <label class="checkbox-label">
                        <input 
                            type="checkbox" 
                            name="ga_track_downloads" 
                            value="1" 
                            <?php echo e(config('analytics.ga_track_downloads', true) ? 'checked' : ''); ?>

                        >
                        <span>Track Video Downloads</span>
                    </label>
                    <small>Track when users download TikTok videos</small>
                    <?php $__errorArgs = ['ga_track_downloads'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('ga_track_donations')]) ?>">
                    <label class="checkbox-label">
                        <input 
                            type="checkbox" 
                            name="ga_track_donations" 
                            value="1" 
                            <?php echo e(config('analytics.ga_track_donations', true) ? 'checked' : ''); ?>

                        >
                        <span>Track Donations</span>
                    </label>
                    <small>Track donation events and amounts</small>
                    <?php $__errorArgs = ['ga_track_donations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Privacy & Advanced Settings Section -->
            <div class="settings-section">
                <h3>Privacy & Advanced Settings</h3>
                
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('ga_anonymize_ip')]) ?>">
                    <label class="checkbox-label">
                        <input 
                            type="checkbox" 
                            name="ga_anonymize_ip" 
                            value="1" 
                            <?php echo e(config('analytics.ga_anonymize_ip', true) ? 'checked' : ''); ?>

                        >
                        <span>Anonymize IP Addresses</span>
                    </label>
                    <small>Anonymize visitor IP addresses for privacy compliance (GDPR)</small>
                    <?php $__errorArgs = ['ga_anonymize_ip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-element', 'is-error'=> $errors->has('ga_debug_mode')]) ?>">
                    <label class="checkbox-label">
                        <input 
                            type="checkbox" 
                            name="ga_debug_mode" 
                            value="1" 
                            <?php echo e(config('analytics.ga_debug_mode') ? 'checked' : ''); ?>

                        >
                        <span>Debug Mode</span>
                    </label>
                    <small>Enable debug mode to see analytics data in browser console (for testing)</small>
                    <?php $__errorArgs = ['ga_debug_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Setup Instructions Section -->
            <div class="settings-section">
                <h3>Setup Instructions</h3>
                <div class="instructions">
                    <ol>
                        <li>Go to <a href="https://analytics.google.com" target="_blank">Google Analytics</a></li>
                        <li>Create a new property or use an existing one</li>
                        <li>Set up a data stream for your website</li>
                        <li>Copy the Measurement ID (starts with G-)</li>
                        <li>Paste it in the "Measurement ID" field above</li>
                        <li>Enable the tracking options you want</li>
                        <li>Save the settings</li>
                        <li>Wait 24-48 hours to see data in Google Analytics</li>
                    </ol>
                </div>
            </div>

            <!-- Testing Section -->
            <div class="settings-section">
                <h3>Testing Your Setup</h3>
                <div class="testing-info">
                    <p><strong>To test if Google Analytics is working:</strong></p>
                    <ul>
                        <li>Enable "Debug Mode" above</li>
                        <li>Open your website in a browser</li>
                        <li>Open Developer Tools (F12)</li>
                        <li>Go to the Console tab</li>
                        <li>You should see "GA4 Debug" messages</li>
                        <li>Check the Network tab for requests to google-analytics.com</li>
                    </ul>
                </div>
            </div>

            <?php $__env->startPush('header'); ?>
                <button class="button is-primary" type="submit" form="googleAnalyticsForm">Save Settings</button>
            <?php $__env->stopPush(); ?>
        </form>
    </div>

    <style>
        .settings-section {
            margin-bottom: 2rem;
            padding: 1.5rem;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }

        .settings-section h3 {
            margin-bottom: 1rem;
            color: #333;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .instructions {
            background: #e3f2fd;
            padding: 1rem;
            border-radius: 6px;
            border-left: 4px solid #2196f3;
        }

        .instructions ol {
            margin: 0;
            padding-left: 1.5rem;
        }

        .instructions li {
            margin-bottom: 0.5rem;
            color: #1976d2;
        }

        .instructions a {
            color: #2196f3;
            text-decoration: underline;
        }

        .testing-info {
            background: #fff3cd;
            padding: 1rem;
            border-radius: 6px;
            border-left: 4px solid #ffc107;
        }

        .testing-info ul {
            margin: 0.5rem 0 0 0;
            padding-left: 1.5rem;
        }

        .testing-info li {
            margin-bottom: 0.25rem;
            color: #856404;
        }

        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
        }

        .checkbox-label input[type="checkbox"] {
            margin: 0;
        }

        input[pattern] {
            font-family: monospace;
        }
    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Espacegamers\Documents\codecanyon apps\web apps\tiktokdown\tiktok\resources\views/admin/google-analytics.blade.php ENDPATH**/ ?>