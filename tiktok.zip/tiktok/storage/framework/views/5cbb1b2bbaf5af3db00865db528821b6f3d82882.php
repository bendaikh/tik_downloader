<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.layout','data' => ['title' => 'AI Integration']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'AI Integration']); ?>
    <div class="content-card card">
        <div class="heading">
            <h2>AI Integration</h2>
            <p>Configure AI-powered features for your application.</p>
        </div>

        <?php if(session('success')): ?>
            <div class="alert success">
                <span><?php echo e(session('success')); ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('admin.ai-integration.update')); ?>">
            <?php echo csrf_field(); ?>

            <!-- AI Enable/Disable -->
            <div class="form-element">
                <label class="checkbox">
                    <input type="checkbox" name="ai_enabled" value="1" <?php echo e(old('ai_enabled', config('ai.enabled', false)) ? 'checked' : ''); ?>>
                    <label>Enable AI Features</label>
                </label>
                <?php $__errorArgs = ['ai_enabled'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- OpenAI API Key -->
            <div class="form-element <?php echo e($errors->has('openai_api_key') ? 'is-error' : ''); ?>">
                <label>OpenAI API Key</label>
                <input type="password" name="openai_api_key" value="<?php echo e(old('openai_api_key', config('services.openai.api_key'))); ?>" placeholder="sk-...">
                <?php $__errorArgs = ['openai_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <small style="color: #6b7280; font-size: 0.875rem; margin-top: 0.25rem; display: block;">
                    Your OpenAI API key for AI-powered features. Get one at <a href="https://platform.openai.com/api-keys" target="_blank" style="color: #3b82f6;">OpenAI Platform</a>
                </small>
            </div>

            <!-- OpenAI Model -->
            <div class="form-element <?php echo e($errors->has('openai_model') ? 'is-error' : ''); ?>">
                <label>OpenAI Model</label>
                <select name="openai_model">
                    <option value="gpt-3.5-turbo" <?php echo e(old('openai_model', config('services.openai.model', 'gpt-3.5-turbo')) == 'gpt-3.5-turbo' ? 'selected' : ''); ?>>GPT-3.5 Turbo (Recommended)</option>
                    <option value="gpt-4" <?php echo e(old('openai_model', config('services.openai.model')) == 'gpt-4' ? 'selected' : ''); ?>>GPT-4 (More Advanced)</option>
                    <option value="gpt-4-turbo" <?php echo e(old('openai_model', config('services.openai.model')) == 'gpt-4-turbo' ? 'selected' : ''); ?>>GPT-4 Turbo (Latest)</option>
                </select>
                <?php $__errorArgs = ['openai_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- AI Temperature -->
            <div class="form-element <?php echo e($errors->has('ai_temperature') ? 'is-error' : ''); ?>">
                <label>AI Creativity Level</label>
                <input type="range" name="ai_temperature" min="0" max="2" step="0.1" value="<?php echo e(old('ai_temperature', config('services.openai.temperature', 0.7))); ?>" 
                       oninput="this.nextElementSibling.textContent = this.value">
                <span style="margin-left: 1rem; font-weight: 600;"><?php echo e(old('ai_temperature', config('services.openai.temperature', 0.7))); ?></span>
                <?php $__errorArgs = ['ai_temperature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <small style="color: #6b7280; font-size: 0.875rem; margin-top: 0.25rem; display: block;">
                    Lower values (0.0-0.5) = More focused and consistent. Higher values (0.6-2.0) = More creative and varied.
                </small>
            </div>

            <!-- Auto Generate Descriptions -->
            <div class="form-element">
                <label class="checkbox">
                    <input type="checkbox" name="auto_generate_descriptions" value="1" <?php echo e(old('auto_generate_descriptions', config('ai.auto_generate_descriptions', false)) ? 'checked' : ''); ?>>
                    <label>Auto-generate Product Descriptions</label>
                </label>
                <?php $__errorArgs = ['auto_generate_descriptions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <small style="color: #6b7280; font-size: 0.875rem; margin-top: 0.25rem; display: block;">
                    Automatically generate compelling product descriptions using AI when creating new products.
                </small>
            </div>

            <!-- Feature Cards -->
            <div style="margin: 2rem 0;">
                <h3 style="margin-bottom: 1rem; color: #374151; font-size: 1.125rem;">Available AI Features</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem;">
                    
                    <!-- Smart Descriptions -->
                    <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem; background: #f9fafb;">
                        <div style="display: flex; align-items: center; margin-bottom: 0.5rem;">
                            <span style="font-size: 1.5rem; margin-right: 0.5rem;">🤖</span>
                            <h4 style="margin: 0; color: #1f2937;">Smart Descriptions</h4>
                        </div>
                        <p style="color: #6b7280; font-size: 0.875rem; margin: 0;">
                            Generate compelling product descriptions that convert visitors into customers using advanced AI.
                        </p>
                    </div>

                    <!-- Content Optimization -->
                    <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem; background: #f9fafb;">
                        <div style="display: flex; align-items: center; margin-bottom: 0.5rem;">
                            <span style="font-size: 1.5rem; margin-right: 0.5rem;">⚡</span>
                            <h4 style="margin: 0; color: #1f2937;">Content Optimization</h4>
                        </div>
                        <p style="color: #6b7280; font-size: 0.875rem; margin: 0;">
                            Optimize existing content for better engagement and search engine visibility.
                        </p>
                    </div>

                    <!-- Blog Post Generation -->
                    <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem; background: #f9fafb;">
                        <div style="display: flex; align-items: center; margin-bottom: 0.5rem;">
                            <span style="font-size: 1.5rem; margin-right: 0.5rem;">📝</span>
                            <h4 style="margin: 0; color: #1f2937;">AI Blog Posts</h4>
                        </div>
                        <p style="color: #6b7280; font-size: 0.875rem; margin: 0;">
                            Generate complete, engaging blog posts from simple prompts to boost your content marketing.
                        </p>
                    </div>

                    <!-- Language Translation -->
                    <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem; background: #f9fafb;">
                        <div style="display: flex; align-items: center; margin-bottom: 0.5rem;">
                            <span style="font-size: 1.5rem; margin-right: 0.5rem;">🌍</span>
                            <h4 style="margin: 0; color: #1f2937;">Multi-language Support</h4>
                        </div>
                        <p style="color: #6b7280; font-size: 0.875rem; margin: 0;">
                            Automatically translate product descriptions and content to reach global audiences.
                        </p>
                    </div>

                </div>
            </div>

            <button type="submit" class="button is-primary">Save AI Settings</button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Espacegamers\Documents\codecanyon apps\web apps\tiktokdown\tiktok\resources\views/admin/ai-integration.blade.php ENDPATH**/ ?>