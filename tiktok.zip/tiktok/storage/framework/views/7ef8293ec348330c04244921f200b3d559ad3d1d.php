<?php foreach($attributes->onlyProps(['href', 'text', 'active' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['href', 'text', 'active' => false]); ?>
<?php foreach (array_filter((['href', 'text', 'active' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $active = $active ?: request()->url() === $href || request()->routeIs($href);
?>

<a <?php echo e($attributes->class([
    'nav-sub-link',
    'is-active' => $active,
])); ?> href="<?php echo e($href); ?>">
    <span><?php echo e($text); ?></span>
</a>
<?php /**PATH C:\Users\Espacegamers\Documents\codecanyon apps\web apps\tiktokdown\tiktok\resources\views/components/admin/nav-sub-link.blade.php ENDPATH**/ ?>