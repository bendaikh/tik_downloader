<?php if(session()->has('message')): ?>
    <?php
        $message = session()->get('message');
    ?>
    <div class="alert <?php echo e($message['type']); ?>" role="alert">
        <span><?php echo e($message['content']); ?></span>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Espacegamers\Documents\codecanyon apps\web apps\tiktokdown\tiktok\resources\views/components/admin/flash.blade.php ENDPATH**/ ?>