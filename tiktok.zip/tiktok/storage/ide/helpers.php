<?php

namespace Illuminate\Support\Facades {

    use Illuminate\Routing\RouteRegistrar;

    /**
     * @method static RouteRegistrar localization()
     */
    class Route extends Facade
    {
    }
}
