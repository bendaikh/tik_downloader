@extends('errors::minimal')

@section('title', __('Not Found'))
@section('code', '404')
@section('message', __('Whoops! There is nothing here. We think you are lost.'))
