<header class="header">
    <div class="container">
        <div class="header-logo">
            <x-admin.icon.codespikex/>
        </div>

        <div class="header-teleport">
            @stack('header')
        </div>
    </div>
</header>
