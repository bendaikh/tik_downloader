<div class="card license-card">
    <h4>License Usage</h4>
    <div class="license-card-content">
        <div class="license-usage">
            {{number_format($licenseData('usage', 0))}} / {{number_format($licenseData('max_usage', 0))}}
        </div>
    </div>
</div>
