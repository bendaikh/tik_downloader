<div class="alert {{$type ?? 'info'}}" role="alert">
    <span>{{$slot ?? $text ?? ''}}</span>
</div>
